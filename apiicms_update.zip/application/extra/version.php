<?php
return array (
    'name' => 'ApiiCMS',
    'copyright' => 'ApiiCMS',
    'url' => '//github.com/apiiphim/ramcms',
    'code' => '3.0',
    'license' => 'MIT',
);
?>